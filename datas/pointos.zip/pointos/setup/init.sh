#!/bin/bash

# Configuração do ambiente Python
export PYTHONPATH=/root/system

# Iniciar o script principal do sistema
python 
